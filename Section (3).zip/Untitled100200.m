clear all;clc;close all;
[count,bincenter]=hist(0.24);
figure
bar(bincenter,0.2*count/sum(count),0.1,'m')
hold on
[count1,bincenter1]=hist(0.26);
bar(bincenter1,0.1*count1/sum(count1),0.1,'m')
hold on
[count2,bincenter2]=hist(0.29);
bar(bincenter2,0.1*count2/sum(count1),0.1,'m')
hold on
[count3,bincenter3]=hist(0.3);
bar(bincenter3,0.2*count3/sum(count1),0.1,'m')
hold on
[count4,bincenter4]=hist(0.31);
bar(bincenter4,0.1*count4/sum(count1),0.1,'m')
hold on
[count5,bincenter5]=hist(0.33);
bar(bincenter5,0.2*count5/sum(count1),0.1,'m')
hold on
[count6,bincenter6]=hist(0.35);
bar(bincenter6,0.12*count6/sum(count1),0.1,'m')
hold on
[count7,bincenter7]=hist(0.37);
bar(bincenter7,0.1*count7/sum(count1),0.1,'m')
hold on
[count8,bincenter8]=hist(0.39);
bar(bincenter8,0.7*count8/sum(count1),0.1,'m')
hold on
[count9,bincenter9]=hist(0.4);
bar(bincenter9,0.7*count9/sum(count1),0.1,'m')
hold on
[count10,bincenter10]=hist(0.42);
bar(bincenter10,0.4*count10/sum(count1),0.1,'m')
hold on
[count11,bincenter11]=hist(0.44);
bar(bincenter11,0.7*count11/sum(count1),0.1,'m')
hold on
[count12,bincenter12]=hist(0.46);
bar(bincenter12,0.2*count12/sum(count1),0.1,'m')
hold on
[count13,bincenter13]=hist(0.48);
bar(bincenter13,0.1*count13/sum(count1),0.1,'m')
hold on
[count14,bincenter14]=hist(0.5);
bar(bincenter14,1.1*count14/sum(count1),0.1,'m')
hold on
[count15,bincenter15]=hist(0.52);
bar(bincenter15,0.5*count15/sum(count1),0.1,'m')
hold on
[count16,bincenter16]=hist(0.54);
bar(bincenter16,0.6*count16/sum(count1),0.1,'m')
hold on
[count17,bincenter17]=hist(0.56);
bar(bincenter17,1.8*count17/sum(count1),0.1,'m')
hold on
[count18,bincenter18]=hist(0.58);
bar(bincenter18,1.9*count18/sum(count1),0.1,'m')
hold on
[count19,bincenter19]=hist(0.6);
bar(bincenter19,2*count19/sum(count1),0.1,'m')
hold on
[count20,bincenter20]=hist(0.62);
bar(bincenter20,1.6*count20/sum(count1),0.1,'m')
hold on
[count21,bincenter21]=hist(0.64);
bar(bincenter21,2*count21/sum(count1),0.1,'m')
hold on
[count22,bincenter22]=hist(0.66);
bar(bincenter22,2.1*count22/sum(count1),0.1,'m')
hold on
[count23,bincenter23]=hist(0.68);
bar(bincenter23,2*count23/sum(count1),0.1,'m')
hold on
[count24,bincenter24]=hist(0.7);
bar(bincenter24,1.5*count24/sum(count1),0.1,'m')
hold on
[count25,bincenter25]=hist(0.72);
bar(bincenter25,2*count25/sum(count1),0.1,'m')
hold on
[count26,bincenter26]=hist(0.74);
bar(bincenter26,3.2*count26/sum(count1),0.1,'m')
hold on
[count27,bincenter27]=hist(0.76);
bar(bincenter27,3.1*count27/sum(count1),0.1,'m')
hold on
[count28,bincenter28]=hist(0.78);
bar(bincenter28,4*count28/sum(count1),0.1,'m')
hold on
[count29,bincenter29]=hist(0.8);
bar(bincenter29,3*count29/sum(count1),0.1,'m')
hold on
[count30,bincenter30]=hist(0.82);
bar(bincenter30,4.1*count30/sum(count1),0.1,'m')
hold on
[count31,bincenter31]=hist(0.84);
bar(bincenter31,2*count31/sum(count1),0.1,'m')
hold on
[count32,bincenter32]=hist(0.86);
bar(bincenter32,4.1*count32/sum(count1),0.1,'m')
hold on
[count33,bincenter33]=hist(0.88);
bar(bincenter33,3*count33/sum(count1),0.1,'m')
hold on
[count34,bincenter34]=hist(0.9);
bar(bincenter34,4.3*count34/sum(count1),0.1,'m')
hold on
[count35,bincenter35]=hist(0.92);
bar(bincenter35,4*count35/sum(count1),0.1,'m')
hold on
[count36,bincenter36]=hist(0.93);
bar(bincenter36,4.5*count36/sum(count1),0.1,'m')
hold on
[count37,bincenter37]=hist(0.94);
bar(bincenter37,3.4*count37/sum(count1),0.1,'m')
hold on
[count38,bincenter38]=hist(0.95);
bar(bincenter38,3.1*count38/sum(count1),0.1,'m')
hold on
[count39,bincenter39]=hist(0.96);
bar(bincenter39,3*count39/sum(count1),0.1,'m')
hold on
[count40,bincenter40]=hist(0.97);
bar(bincenter40,3.2*count40/sum(count1),0.1,'m')
hold on
[count41,bincenter41]=hist(0.98);
bar(bincenter41,1.1*count41/sum(count1),0.1,'m')
hold on
[count42,bincenter42]=hist(0.99);
bar(bincenter42,1*count42/sum(count1),0.1,'m')
hold on
[count43,bincenter43]=hist(1);
bar(bincenter43,0.7*count43/sum(count1),0.1,'m')
title('Histograms of coefficient  C3')
ylabel('% percent of Distribution for Amplitude (100-200)')
