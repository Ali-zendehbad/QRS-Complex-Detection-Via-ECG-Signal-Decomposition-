clc;clear;close all;
fid=fopen('ecgca445.edf','r');
bytes=fread(fid,'int16');
fclose(fid);
b=bytes(1:100000,:);
subplot(3,3,1);plot(b);grid on
title('Fetal ECG 445 in physiont')
%****************************************
m=b(1000:4000);
x=m+475;
subplot(3,3,2);plot(x);grid on
title('Fetal ECG 445 in physiont')
%****************************************
fs=250;
Q=1;
w0=(60/(fs/2));
bw=w0/Q;
[b,a]=iirnotch(w0,bw);
fvtool(b,a)
o=filtfilt(b,a,x)
subplot(3,3,3);plot(o);grid on
title('after of notch filter')
%****************************************
r=5;
b=ones(r,1)/r;
y=filter(b,1,o);
subplot(3,3,4);plot(y);grid on
title('ECG after M.V')
%*****************************************
N=50
win=rectwin(N+1);
Wvtool(rectwin(N+1))
Fc=30;  wn=30*(2/250);
t=fir1(50,wn,'low',win);
yy=filter(t,1,y);
Fp=6;      Wn=6*(2/250);
t=fir1(50,Wn,'high',win);
yyy=filter(t,1,yy);
subplot(3,3,5);plot(yyy);grid on
title('signal after low and high filter')
%******************************************
d1=[2 1 0 -1 -2];
diff=filter(d1,1,yyy);
subplot(3,3,6);plot(diff);grid on
title('signal after differentiator')
sqr=diff.^2;
subplot(3,3,7);plot(sqr);grid on
title('signal after squre')
number=40;   %number of sample for window
u=(1/number)*ones(1,number);
mov=filter(u,1,sqr)  %running integrator
subplot(3,3,8);plot(mov);grid on
title('signal after running integrator')
%*****************************************
hold on;
ter=0.7*mean(mov)   %threshold  from  algorithm
for i=1:3000;
    if mov(i)<1000000
        mov(i)=ter;
    end
end
subplot(3,3,9);plot((mov),'m');grid on
title('Detection Of QRS')


